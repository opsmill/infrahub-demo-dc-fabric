====================
Getting Started
====================

.. toctree::
   :maxdepth: 4

   Installation <installation>
   How to Use <how-to-use>